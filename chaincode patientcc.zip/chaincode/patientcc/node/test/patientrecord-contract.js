/*
 * SPDX-License-Identifier: Apache-2.0
 */

'use strict';

const { ChaincodeStub, ClientIdentity } = require('fabric-shim');
const { PatientrecordContract } = require('..');
const winston = require('winston');

const chai = require('chai');
const chaiAsPromised = require('chai-as-promised');
const sinon = require('sinon');
const sinonChai = require('sinon-chai');

chai.should();
chai.use(chaiAsPromised);
chai.use(sinonChai);

class TestContext {

    constructor() {
        this.stub = sinon.createStubInstance(ChaincodeStub);
        this.clientIdentity = sinon.createStubInstance(ClientIdentity);
        this.logger = {
            getLogger: sinon.stub().returns(sinon.createStubInstance(winston.createLogger().constructor)),
            setLevel: sinon.stub(),
        };
    }

}

describe('PatientrecordContract', () => {

    let contract;
    let ctx;

    beforeEach(() => {
        contract = new PatientrecordContract();
        ctx = new TestContext();
        ctx.stub.getState.withArgs('1001').resolves(Buffer.from('{"value":"patientrecord 1001 value"}'));
        ctx.stub.getState.withArgs('1002').resolves(Buffer.from('{"value":"patientrecord 1002 value"}'));
    });

    describe('#patientrecordExists', () => {

        it('should return true for a patientrecord', async () => {
            await contract.patientrecordExists(ctx, '1001').should.eventually.be.true;
        });

        it('should return false for a patientrecord that does not exist', async () => {
            await contract.patientrecordExists(ctx, '1003').should.eventually.be.false;
        });

    });

    describe('#createPatientrecord', () => {

        it('should create a patientrecord', async () => {
            await contract.createPatientrecord(ctx, '1003', 'patientrecord 1003 value');
            ctx.stub.putState.should.have.been.calledOnceWithExactly('1003', Buffer.from('{"value":"patientrecord 1003 value"}'));
        });

        it('should throw an error for a patientrecord that already exists', async () => {
            await contract.createPatientrecord(ctx, '1001', 'myvalue').should.be.rejectedWith(/The patientrecord 1001 already exists/);
        });

    });

    describe('#readPatientrecord', () => {

        it('should return a patientrecord', async () => {
            await contract.readPatientrecord(ctx, '1001').should.eventually.deep.equal({ value: 'patientrecord 1001 value' });
        });

        it('should throw an error for a patientrecord that does not exist', async () => {
            await contract.readPatientrecord(ctx, '1003').should.be.rejectedWith(/The patientrecord 1003 does not exist/);
        });

    });

    describe('#updatePatientrecord', () => {

        it('should update a patientrecord', async () => {
            await contract.updatePatientrecord(ctx, '1001', 'patientrecord 1001 new value');
            ctx.stub.putState.should.have.been.calledOnceWithExactly('1001', Buffer.from('{"value":"patientrecord 1001 new value"}'));
        });

        it('should throw an error for a patientrecord that does not exist', async () => {
            await contract.updatePatientrecord(ctx, '1003', 'patientrecord 1003 new value').should.be.rejectedWith(/The patientrecord 1003 does not exist/);
        });

    });

    describe('#deletePatientrecord', () => {

        it('should delete a patientrecord', async () => {
            await contract.deletePatientrecord(ctx, '1001');
            ctx.stub.deleteState.should.have.been.calledOnceWithExactly('1001');
        });

        it('should throw an error for a patientrecord that does not exist', async () => {
            await contract.deletePatientrecord(ctx, '1003').should.be.rejectedWith(/The patientrecord 1003 does not exist/);
        });

    });

});
