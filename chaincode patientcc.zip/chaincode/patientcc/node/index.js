/*
 * SPDX-License-Identifier: Apache-2.0
 */

'use strict';

const PatientrecordContract = require('./lib/patientrecord-contract');

module.exports.PatientrecordContract = PatientrecordContract;
module.exports.contracts = [ PatientrecordContract ];
